READ ME

For parametric values, please refer to file ald_tech.tek.


For example, ires = 1.0 and cox = 1.0.

